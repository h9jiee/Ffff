package com.example.tsukaretasama

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 20, 32)
    private val panel = Color.rgb(28, 35, 52)
    private val accent = Color.rgb(132, 169, 255)
    private val text = Color.rgb(241, 244, 250)
    private val muted = Color.rgb(184, 194, 214)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(label("疲れた様", 30, text, true))
        root.addView(label("Локальный помощник по цифровой безопасности", 15, muted, false).apply {
            setPadding(0, dp(4), 0, dp(20))
        })

        val passwordPanel = card()
        passwordPanel.addView(label("Проверка надёжности пароля", 20, text, true))
        passwordPanel.addView(label(
            "Проверка выполняется только на этом устройстве. Пароль не отправляется и не сохраняется.",
            14, muted, false
        ).apply { setPadding(0, dp(8), 0, dp(12)) })

        val password = EditText(this).apply {
            hint = "Введи тестовый пароль"
            setHintTextColor(muted)
            setTextColor(text)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(40, 48, 68))
        }
        passwordPanel.addView(password, matchWrap())

        val check = Button(this).apply {
            text = "Оценить пароль"
            setTextColor(Color.rgb(12, 18, 32))
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent))
        }
        passwordPanel.addView(check, matchWrap().apply { topMargin = dp(10) })

        val result = label("Оценка появится здесь.", 15, muted, false)
        result.setPadding(0, dp(12), 0, 0)
        passwordPanel.addView(result)
        check.setOnClickListener {
            val value = password.text?.toString().orEmpty()
            result.text = assessPassword(value)
        }
        root.addView(passwordPanel, matchWrap().apply { bottomMargin = dp(16) })

        val wifiPanel = card()
        wifiPanel.addView(label("Как защитить домашний Wi‑Fi", 20, text, true))
        wifiPanel.addView(label(
            "• Используй WPA2-AES или WPA3, если роутер поддерживает.\n\n" +
            "• Установи уникальный пароль администратора роутера.\n\n" +
            "• Обновляй прошивку роутера и отключи WPS, если он не нужен.\n\n" +
            "• Создай гостевую сеть для гостей и умных устройств.\n\n" +
            "• Не сообщай пароль сети незнакомым людям.",
            15, muted, false
        ).apply { setPadding(0, dp(10), 0, 0) })
        root.addView(wifiPanel, matchWrap().apply { bottomMargin = dp(16) })

        root.addView(label(
            "Учебный проект. Приложение не сканирует сети, не подключается к Wi‑Fi и не пытается подбирать пароли.",
            13, muted, false
        ))
    }

    private fun assessPassword(value: String): String {
        if (value.isEmpty()) return "Сначала введи тестовый пароль."
        var score = 0
        if (value.length >= 12) score++
        if (value.length >= 16) score++
        if (value.any { it.isLowerCase() } && value.any { it.isUpperCase() }) score++
        if (value.any { it.isDigit() }) score++
        if (value.any { !it.isLetterOrDigit() }) score++
        return when {
            value.length < 8 -> "Слабый: используй длинную уникальную фразу (лучше 12+ символов)."
            score <= 2 -> "Средний: добавь длину и разнообразие символов; не используй личные данные."
            else -> "Хороший ориентир, но это лишь приблизительная оценка. Используй уникальный пароль для каждого сервиса."
        }
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundColor(panel)
    }

    private fun label(value: String, size: Int, color: Int, bold: Boolean) =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.START
        }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
